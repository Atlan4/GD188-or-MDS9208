
#include <string.h>

#include "lcd.h"
#include "meas_chip.h"
#include "rotary_switch.h"


MeasChip_t MeasChip = {0};

static uint8_t rx_buffer[16];
uint8_t rx_index = 0;

// Pomocná funkcia na výpočet kontrolného súčtu
static uint8_t CalculateChecksum(const uint8_t *data, uint8_t length) {
    uint8_t sum = 0;
    for (uint8_t i = 0; i < length; i++) {
        sum += data[i];
    }
    return sum;
}

// Odoslanie paketu s automatickým dopočítaním checksumu
static void SendPacket(const uint8_t *payload, uint8_t payload_len) {
    uint8_t tx_buf[8];
    if (payload_len > 7) return;

    memcpy(tx_buf, payload, payload_len);
    tx_buf[payload_len] = CalculateChecksum(payload, payload_len);

    HAL_UART_Transmit(&huart6, tx_buf, payload_len + 1, 50);
}

void MeasChip_Init(void) {
    memset(&MeasChip, 0, sizeof(MeasChip_t));
    memset(rx_buffer, 0, sizeof(rx_buffer));
    rx_index = 0;
    MeasChip.init_state = INIT_STEP_IDLE;
}

// Plne automatizovaná funkcia na prepínanie režimov meracieho čipu
void MeasChip_SetMode(uint8_t mode_cmd) {
    if (mode_cmd == CMD_CHIP_UNKNOWN) return; // Ak je koleso v medzipolohe, nič neposielame

    // Nastavenie pôvodných inicializačných stavov
    MeasChip.init_state = INIT_STEP_SET_MODE;
    MeasChip.last_cmd_tick = HAL_GetTick();

    // ČISTÉ DÁTA (Payload): Iba Hlavička a Príkaz (Rozmer 2 bajty)
    uint8_t payload[2];
    payload[0] = 0x58;      // Fixná hlavička balíka
    payload[1] = mode_cmd;  // Kód meracieho rozsahu

    // SendPacket zoberie tieto 2 bajty, pridá k nim vypočítaný CS a odošle 3 bajty na UART
    SendPacket(payload, sizeof(payload));
}

// Plne automatizovaná funkcia na odoslanie AUTO alebo MANUAL režimu
void MeasChip_SetRange(uint8_t mode_cmd) {
    if (mode_cmd == CMD_CHIP_UNKNOWN) return;

    // OPRAVA: Dynamicky nastavíme stav podľa toho, aké tlačidlo používateľ stlačil!
    if (mode_cmd == CMD_CHIP_MANUAL) {
        // Ak posielame 0x5B, nastavíme čistý stav očakávania manuálu
        MeasChip.init_state = INIT_STEP_SET_MAN;
    }
    else if (mode_cmd == CMD_CHIP_AUTO) {
        // Ak posielame 0x5A, nastavíme čistý stav očakávania automatiky
        MeasChip.init_state = INIT_STEP_SET_AUTO;
    }

    MeasChip.last_cmd_tick = HAL_GetTick();

    uint8_t payload[1];
    payload[0] = mode_cmd;  // Kód meracieho rozsahu (0x5A alebo 0x5B)

    // SendPacket zoberie povel, prihodí CS a odošle 2 bajty na UART
    SendPacket(payload, sizeof(payload));
}






// Pravidelné vyžiadanie dát z čipu podľa aktuálnej polohy prepínača
void MeasChip_RequestData(void) {
    if (MeasChip.init_state == INIT_STEP_READY) {
        SwitchPosition_t current_pos = ROTARY_GetSwitchPosition();
        uint8_t req_byte = 0x60;

        switch (current_pos) {
            case SWITCH_POS_Cx:
                req_byte = 0x61; // Vyžiadanie kapacity (SendPacket odošle 61 61)
                break;

            case SWITCH_POS_Hz_Pct:
                req_byte = 0x62; // Vyžiadanie frekvencie (SendPacket odošle 62 62)
                break;

            default:
                req_byte = 0x60; // Vyžiadanie ostatných veličín (SendPacket odošle 60 60)
                break;
        }

        uint8_t cmd[1] = {req_byte};
        SendPacket(cmd, sizeof(cmd)); // Odošle čistý bajt + automatický CS
        //LCD_DrawString(150, 45, "         ", LCD_RED, LCD_BLACK, 2);
    }

    // Timeout ochrana: Ak čip neodpovedá, skúsime rekonfigurovať aktuálny režim
    else if (MeasChip.init_state != INIT_STEP_IDLE) {
        if (HAL_GetTick() - MeasChip.last_cmd_tick > 500) {
            SwitchPosition_t current_pos = ROTARY_GetSwitchPosition();

            // Určíme bezpečný základný sub-režim pre re-inicializáciu
            SubMode_t safe_sub = (current_pos == SWITCH_POS_OHM_DIODE_CONT) ? SUB_MODE_RESISTANCE : SUB_MODE_DC;
            uint8_t active_cmd = ROTARY_GetChipCommand(current_pos, safe_sub);

            MeasChip_SetMode(active_cmd);

            LCD_DrawString(150, 45, "CHYBA DAT", LCD_RED, LCD_BLACK, 2);
            HAL_Delay(1000);
        }
    }

}



// STRIGENTNÝ A FLEXIBILNÝ PARSER (DOPLNENÁ PODPORA PRE MANUÁLNY REŽIM 0x5B)
void MeasChip_ProcessByte(uint8_t byte) {
    if (rx_index >= sizeof(rx_buffer)) {
        rx_index = 0;
    }

    rx_buffer[rx_index++] = byte;

    // --- SYNCHRONIZÁCIA: Prvý bajt MUSÍ byť platná hlavička protokolu ---
    if (rx_index == 1) {
        // OPRAVA 1: Pridali sme 0x5B medzi trvalo akceptované štartovacie hlavičky
        if (byte != 0xA0 && byte != 0x58 && byte != 0x5A && byte != 0x5B &&
            byte != 0x60 && byte != 0x61 && byte != 0x62) {
            rx_index = 0; // Neznámy bajt zahodíme a hľadáme začiatok znova
            return;
        }
    }

    // 1. Spracovanie uvítacieho paketu: A0 01 A1 (dĺžka 3 bajty)
    if (rx_buffer[0] == 0xA0 && rx_index == 3) {
        if (rx_buffer[2] == CalculateChecksum(rx_buffer, 2)) {
            MeasChip.chip_present = true;
        }
        rx_index = 0;
        return;
    }

    // Sekcia 2 vo tvojej funkcii MeasChip_ProcessByte (súbor lcd.c)
    // Potvrdenie módu: 58 [MODE] [CS] (dĺžka 3 bajty)
    if (rx_buffer[0] == 0x58 && rx_index == 3) {
        if (rx_buffer[2] == CalculateChecksum(rx_buffer, 2)) {
            if (MeasChip.init_state == INIT_STEP_SET_MODE) {
                // Krok 2: Mód bol čipom úspešne potvrdený.
                // PARSER SÁM bezpečne vyvolá odoslanie AUTO režimu (0x5A)
                MeasChip_SetRange(CMD_CHIP_AUTO);
            }
        }
        rx_index = 0;
        return;
    }

    // 3. Potvrdenie Auto režimu: 5A 00 5A (dĺžka 3 bajty)
    if (rx_buffer[0] == 0x5A && rx_index == 3) {
        if (rx_buffer[2] == CalculateChecksum(rx_buffer, 2)) {
            if (MeasChip.init_state == INIT_STEP_SET_AUTO) {
                MeasChip.init_state = INIT_STEP_READY;
                //MeasChip.is_valid = true;
            }
        }
        rx_index = 0;
        return;
    }

    // Spracovanie odpovede čipu na manuálnu zmenu rozsahu: 5B [ROZSAH] [CS]
    if (rx_buffer[0] == 0x5B && rx_index == 3) {
        if (rx_buffer[2] == CalculateChecksum(rx_buffer, 2)) {

            // Reagujeme iba vtedy, ak sme v stave INIT_STEP_SET_MAN
            if (MeasChip.init_state == INIT_STEP_SET_MAN) {
                MeasChip.range = rx_buffer[1];
                MeasChip.init_state = INIT_STEP_READY; // Sme úspešne hotoví!
                MeasChip.is_valid = true;
            }
        }
        rx_index = 0;
        return;
    }



    // 4a. Spracovanie štandardného dátového balíka: 0x60 (Celková dĺžka 6 bajtov)
    if (rx_buffer[0] == 0x60 && rx_index == 6) {
        if (rx_buffer[5] == CalculateChecksum(rx_buffer, 5)) {
            MeasChip.packet_type = 0x60;
            MeasChip.raw_value = (int16_t)((rx_buffer[2] << 8) | rx_buffer[1]);
            MeasChip.range = rx_buffer[4];
            MeasChip.is_valid = true;
        }
        rx_index = 0;
        return;
    }

    // 4b. Spracovanie balíka kapacity: 0x61 (Celková dĺžka 7 bajtov, napr. 61 xx xx xx xx xx CS)
    if (rx_buffer[0] == 0x61 && rx_index == 7) {
        if (rx_buffer[6] == CalculateChecksum(rx_buffer, 6)) {
            MeasChip.packet_type = 0x61;
            MeasChip.raw_value = (int16_t)((rx_buffer[2] << 8) | rx_buffer[1]);
            MeasChip.range = rx_buffer[4];
            MeasChip.is_valid = true;
        }
        rx_index = 0;
        return;
    }

    // 4c. Spracovanie balíka frekvencie: 0x62 (Celková dĺžka 4 bajty, napr. 62 xx xx CS)
    if (rx_buffer[0] == 0x62 && rx_index == 4) {
        if (rx_buffer[3] == CalculateChecksum(rx_buffer, 3)) {
            MeasChip.packet_type = 0x62;
            MeasChip.raw_value = (int16_t)((rx_buffer[2] << 8) | rx_buffer[1]);
            MeasChip.range = 0;
            MeasChip.is_valid = true;
        }
        rx_index = 0;
        return;
    }
}
