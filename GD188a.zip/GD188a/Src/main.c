/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include <string.h>
#include <stdio.h>

#include "lcd.h"   
#include "meas_chip.h" // Naše predchádzajúce hlavičky pre merací čip
#include "rotary_switch.h"
#include "button.h"


/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

//uint8_t rx_byte;
//char disp_buffer[20]; // <-- Skontrolujte, či tu máte [20] a NIE iba char disp_buffer;


uint8_t rx_byte;
uint8_t debug_rx_buffer[16];
volatile uint8_t debug_rx_index = 0;
char disp_buffer[24];
char hex_string[32];

uint32_t last_tick = 0;

// Globálna premenná, ktorú bude main.c bleskovo čítať
volatile uint8_t exti_button_cmd = 0x00;

extern uint8_t rx_index;


// Globálne stavové premenné pre multimeter (čítané aj modulom button.c v EXTI)
volatile SubMode_t current_sub_mode = SUB_MODE_DC;
volatile uint8_t last_rotary_cmd = 0xFF;
volatile uint8_t last_button_cmd = 0xFF;

// PRIDANÝ RIADOK: Stráži, či je funkcia zamrazenia údajov aktívna
volatile bool is_hold_active = false;



/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART6_UART_Init();
  MX_TIM5_Init();
  /* USER CODE BEGIN 2 */

  LCD_PWR_PORT->BSRR = (1 << (LCD_PWR_PIN + 16));
  HAL_Delay(250);

  // Initialize display power pins
    LCD_Power_Accessories();
    LCD_Init_Hardware();

    // Clear internal states of measurement chip driver structure
    MeasChip_Init();

    // Start background interrupt data capture via USART6 immediately
    HAL_UART_Receive_IT(&huart6, &rx_byte, 1);

    LCD_Init();

    LCD_DrawString(85, 200, "Firmware v0.14", LCD_YELLOW, LCD_BLACK, 2);

    // Phase 1: Wait for the chip to boot up and transmit A0 01 A1 package
    LCD_DrawString(10, 100, "INITIALIZING MEAS CHIP...", LCD_WHITE, LCD_BLACK, 2);

    // Stay in loop until chip_present is flagged by incoming A0 01 A1 parser logic
    while (!MeasChip.chip_present) {
        // Small delay loop watchdog indicator could be added here if needed
        HAL_Delay(100);
    }
    HAL_Delay(100); // Short stabilization pause for visual notification

    // Phase 2: A0 01 A1 successfully received, print confirmation
    LCD_DrawString(10, 100, "   MEAS CHIP BOOTED OK     ", LCD_GREEN, LCD_BLACK, 2);
    //HAL_Delay(100); // Short stabilization pause for visual notification


    HAL_Delay(800); // Short pause before diving into periodic telemetry request loop


    // Clean the screen canvas
    LCD_Clear(LCD_BLACK);


    // Lokálne statické premenné pre detekciu mechanických zmien kolesa a časovača zbernice
    static SwitchPosition_t last_pos = (SwitchPosition_t)0xFF;
    static uint32_t last_tick = 0;

    // Zviditeľníme príkaz prichádzajúci bleskovo z hardvérového EXTI prerušenia v button.c
    //extern volatile uint8_t exti_button_cmd;

  /* USER CODE END 2 */



  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */



	  // --- 1. KONTROLA OTOČNÉHO PREPÍNAČA ROZSAHOV ---
	       SwitchPosition_t current_pos = ROTARY_GetSwitchPosition();

	       if (current_pos != last_pos) {
	           last_pos = current_pos;
	           is_hold_active = false; // Otočenie gombíka vždy vypne HOLD zobrazenie


	           // [PRIDANÝ RIADOK]: Okamžite po otočení prekreslí spodnú lištu s popiskami pre vybranú veličinu
	           LCD_DrawBottomMenu(current_pos);

	           // Pri mechanickom otočení kolesa natvrdo resetujeme sub-módy do východiskového stavu
	           if (current_pos == SWITCH_POS_OHM_DIODE_CONT)  current_sub_mode = SUB_MODE_RESISTANCE;
	           else if (current_pos == SWITCH_POS_Cx)         current_sub_mode = SUB_MODE_CAPACITANCE;
	           else if (current_pos == SWITCH_POS_Hz_Pct)     current_sub_mode = SUB_MODE_FREQ;
	           else                                           current_sub_mode = SUB_MODE_DC;
	       }

	       // --- 2. PREBRATIE AKCIE Z HARDVÉROVÉHO PRERUŠENIA MATICE ---
	       uint8_t button_action_cmd = exti_button_cmd;
	       exti_button_cmd = CMD_CHIP_UNKNOWN; // Vynulujeme príznak, akcia z prerušenia bola spotrebovaná

	       // --- 3. SYNCHRONIZÁCIA ODOSIELANIA ---
	       // OPRAVA 2: Zadefinovaná premenná rotary_base_cmd, aby prekladač nehlásil chybu na riadku 229
	       uint8_t active_cmd = ROTARY_GetChipCommand(current_pos, current_sub_mode);
	       uint8_t rotary_base_cmd = active_cmd;

	       // 4a. PRÍPAD: Používateľ mechanicky otočil KOLESOM prepínača rozsahov
	       if (rotary_base_cmd != last_rotary_cmd && button_action_cmd == CMD_CHIP_UNKNOWN && active_cmd != CMD_CHIP_UNKNOWN) {
	           last_rotary_cmd = rotary_base_cmd;
	           last_button_cmd = CMD_CHIP_AUTO;

	           MeasChip.init_state = INIT_STEP_SET_MODE;
	           MeasChip.last_cmd_tick = HAL_GetTick();

	           //extern uint8_t rx_index;
	           //rx_index = 0;

	           MeasChip_SetMode(active_cmd);
	           last_tick = HAL_GetTick();
	       }

	       // 4b. PRÍPAD: Hardvérové EXTI prerušenie vygenerovalo akciu z gumeného tlačidla
	       else if (button_action_cmd != CMD_CHIP_UNKNOWN) {
	           // OPRAVA 1: Pustíme príkaz dnu aj vtedy, ak sme už v manuálnom režime READY!
	           if (MeasChip.init_state == INIT_STEP_READY) {

	               if (button_action_cmd == CMD_CHIP_AUTO) {
	                   last_button_cmd = CMD_CHIP_AUTO;
	                   MeasChip.init_state = INIT_STEP_SET_AUTO;
	                   MeasChip.last_cmd_tick = HAL_GetTick();
	                   rx_index = 0;
	                   MeasChip_SetRange(CMD_CHIP_AUTO); // Odošle 5A 5A
	               }
	               else if (button_action_cmd == CMD_CHIP_MANUAL) {
	                   last_button_cmd = CMD_CHIP_MANUAL;

	                   // REFORMA: Nastavíme čistý dedikovaný stav pre manuálny rozsah!
	                   MeasChip.init_state = INIT_STEP_SET_MAN;
	                   MeasChip.last_cmd_tick = HAL_GetTick();


	                   rx_index = 0;

	                   MeasChip_SetRange(CMD_CHIP_MANUAL); // Odošle 5B 5B
	               }

	               else {
	                   // Tlačidlo SEL zmenilo sub_mode (DC -> AC) -> tu reštart módu potrebujeme
	                   last_rotary_cmd = button_action_cmd;
	                   MeasChip.init_state = INIT_STEP_SET_MODE;
	                   MeasChip.last_cmd_tick = HAL_GetTick();
	                   MeasChip_SetMode(button_action_cmd);
	               }

	               last_tick = HAL_GetTick();
	           }
	       }






	       // --- SPRACOVANIE STAVOVÉHO STROJA A VÝPIS STATUSU ---
	       if (MeasChip.init_state == INIT_STEP_SET_MODE) {
	           char status_str[23];
	           snprintf(status_str, sizeof(status_str), "STATUS: WAIT FOR 58 %02X", last_rotary_cmd);
	           LCD_DrawString(10, 10, status_str, LCD_WHITE, LCD_BLACK, 2);
	       } else if (MeasChip.init_state == INIT_STEP_SET_AUTO) {
	           LCD_DrawString(10, 10, "STATUS: WAIT FOR 5A 00", LCD_WHITE, LCD_BLACK, 2);
	       } else if (MeasChip.init_state == INIT_STEP_SET_MAN) {
               // NOVÁ HLÁŠKA: Jasne vidíš, že prístroj čaká na potvrdenie 0x5B z čipu
	           LCD_DrawString(10, 10, "STATUS: WAIT FOR 5B REQ", LCD_WHITE, LCD_BLACK, 2);
	       } else if (MeasChip.init_state == INIT_STEP_READY) {
	           LCD_DrawString(10, 10, "STATUS: TELEMETRY ACTIVE ", LCD_GREEN, LCD_BLACK, 2);
	       }


	       // Vyžiadanie dát každých 200 ms, ak je inicializácia úspešne dokončená (READY)
	       if ((HAL_GetTick() - last_tick >= 200) && (MeasChip.init_state == INIT_STEP_READY)) {
	           last_tick = HAL_GetTick();
	           MeasChip_RequestData();
	       }

	       // --- RAW DATA SNIFFER (Zobrazuje prichádzajúci stream z čipu) ---
	       snprintf(hex_string, sizeof(hex_string), "%02X %02X %02X %02X %02X %02X %02X %02X",
	                debug_rx_buffer[0], debug_rx_buffer[1], debug_rx_buffer[2], debug_rx_buffer[3],
	                debug_rx_buffer[4], debug_rx_buffer[5], debug_rx_buffer[6], debug_rx_buffer[7]);
	       LCD_DrawString(25, 165, hex_string, LCD_YELLOW, LCD_BLACK, 2);

	       snprintf(hex_string, sizeof(hex_string), "%02X %02X %02X %02X %02X %02X %02X %02X",
	                debug_rx_buffer[8], debug_rx_buffer[9], debug_rx_buffer[10], debug_rx_buffer[11],
	                debug_rx_buffer[12], debug_rx_buffer[13], debug_rx_buffer[14], debug_rx_buffer[15]);
	       LCD_DrawString(25, 185, hex_string, LCD_YELLOW, LCD_BLACK, 2);


	//************************************************



	       // --- 5. DUPLIKOVANÁ ZOBRAZOVACIA LOGIKA (JEDNOTKA HORE AJ NA OKRAJI) ---
	       if (MeasChip.is_valid) {

	           // PRIDANÝ RIADOK PRE HOLD: Ak používateľ aktivoval HOLD, stopneme prepisovanie displeja!
	           if (is_hold_active) {
	               MeasChip.is_valid = false;
	               goto end_of_display_loop; // Preskočíme celé prekreslenie veľkých čísiel aj riadku 45
	           }

	           int16_t abs_raw = MeasChip.raw_value;
	           if (abs_raw < 0) abs_raw = -abs_raw;

	           // HARDVÉROVÁ FILTRÁCIA: Ochrana pre rozsah mV
	           if (current_pos == SWITCH_POS_mV && MeasChip.range > 1) {
	               MeasChip.is_valid = false;
	               goto end_of_display_loop;
	           }

	           char num_str[8];
	           uint16_t txt_color = LCD_YELLOW;

	           static uint8_t last_range = 0xFF;
	           static uint8_t last_ac_dc_cmd = 0xFF;

	           uint16_t digit_step = FONT_7SEG_WIDTH + 12; // Krok pre 45px šírku cifier
	           uint16_t units_x = 10 + (5 * digit_step);   // Pozícia pre jednotky na pravom okraji

	           uint16_t dot_size = 7;
	           uint16_t dot_clear_y = 70 + (FONT_7SEG_HEIGHT - dot_size);

	           // --- SEKCE A: RIADENIE REŽIMOV A VEĽKÝCH JEDNOTIEK NA OKRAJI (RIADOK 75 A 125) ---
	           if (MeasChip.range != last_range || last_rotary_cmd != last_ac_dc_cmd) {
	               last_range = MeasChip.range;
	               last_ac_dc_cmd = last_rotary_cmd;

	               // Vyčistíme staré desatinné bodky v medzerách medzi ciferami
	               for (uint16_t r = 0; r < dot_size; r++) {
	                   LCD_DrawFastHLine(10 + (2 * digit_step) - 10, dot_clear_y + r, 10, LCD_BLACK);
	                   LCD_DrawFastHLine(10 + (3 * digit_step) - 10, dot_clear_y + r, 10, LCD_BLACK);
	                   LCD_DrawFastHLine(10 + (4 * digit_step) - 10, dot_clear_y + r, 10, LCD_BLACK);
	               }

	               // Vyčistenie starých textov na pravom okraji
	               LCD_DrawString(units_x - 5, 75, "  ", LCD_BLACK, LCD_BLACK, 2);
	               LCD_DrawString(units_x - 5, 125, "  ", LCD_BLACK, LCD_BLACK, 2);

	               // Vykreslenie sub-módu AC / DC (Zelená / Oranžová)
	               if (last_rotary_cmd == CMD_CHIP_6V_AC || last_rotary_cmd == CMD_CHIP_600mV_AC ||
	                   last_rotary_cmd == CMD_CHIP_uA_AC || last_rotary_cmd == CMD_CHIP_mA_AC ||
	                   last_rotary_cmd == CMD_CHIP_10A_AC)
	               {
	                   LCD_DrawString(units_x - 5, 75, "AC", LCD_ORANGE, LCD_BLACK, 2);
	               }
	               else {
	                   LCD_DrawString(units_x - 5, 75, "DC", LCD_GREEN, LCD_BLACK, 2);
	               }

	               // UKAZOVATEĽ 1 (VEĽKÝ OKRAJ): Bezpečné vykreslenie veľkej jednotky na riadok 125
	               if ((last_rotary_cmd == CMD_CHIP_6V_DC || last_rotary_cmd == CMD_CHIP_6V_AC) && MeasChip.range == 0) {
	                   LCD_DrawString(units_x - 5, 125, "mV", txt_color, LCD_BLACK, 2);
	               }
	               else if (last_rotary_cmd == CMD_CHIP_600mV_DC || last_rotary_cmd == CMD_CHIP_600mV_AC) {
	                   LCD_DrawString(units_x - 5, 125, "mV", txt_color, LCD_BLACK, 2);
	               }
	               else if (last_rotary_cmd == CMD_CHIP_uA_DC || last_rotary_cmd == CMD_CHIP_uA_AC) {
	                   LCD_DrawString(units_x - 5, 125, "uA", txt_color, LCD_BLACK, 2);
	               }
	               else if (last_rotary_cmd == CMD_CHIP_mA_DC || last_rotary_cmd == CMD_CHIP_mA_AC) {
	                   LCD_DrawString(units_x - 5, 125, "mA", txt_color, LCD_BLACK, 2);
	               }
	               else if (last_rotary_cmd == CMD_CHIP_10A_DC || last_rotary_cmd == CMD_CHIP_10A_AC) {
	                   LCD_DrawString(units_x - 5, 125, "A ", txt_color, LCD_BLACK, 2);
	               }
	               else {
	                   LCD_DrawString(units_x - 5, 125, "V ", txt_color, LCD_BLACK, 2);
	               }
	           }

	           // --- SEKCE B: VYKRESLENIE VEĽKÝCH SEDEMSEGMENTOVÝCH CIFER ---
	           char sign_char = (MeasChip.raw_value < 0) ? '-' : ' ';
	           snprintf(num_str, sizeof(num_str), "%c%04d", sign_char, abs_raw);

	           for(int i = 0; i < 5; i++) {
	               LCD_Draw7SegDigit(10 + i * digit_step, 70, num_str[i], txt_color, LCD_BLACK);
	           }

	           // --- SEKCE C: MASKY A MALÉ JEDNOTKY HORE VEDĽA ČÍSLA (RIADOK 45) ---
	           const char* range_mode_str = (last_button_cmd == CMD_CHIP_MANUAL) ? "MAN " : "AUTO";

	           // POMOCNÝ VÝBER JEDNOTKY: Zistíme správnu skratku podľa prebiehajúceho hardvérového kódu
	           const char* unit_str = "V ";

	           if ((last_rotary_cmd == CMD_CHIP_6V_DC || last_rotary_cmd == CMD_CHIP_6V_AC) && MeasChip.range == 0) {
	               unit_str = "mV";
	           }
	           else if (last_rotary_cmd == CMD_CHIP_600mV_DC || last_rotary_cmd == CMD_CHIP_600mV_AC) {
	               unit_str = "mV";
	           }
	           else if (last_rotary_cmd == CMD_CHIP_uA_DC || last_rotary_cmd == CMD_CHIP_uA_AC) {
	               unit_str = "uA";
	           }
	           else if (last_rotary_cmd == CMD_CHIP_mA_DC || last_rotary_cmd == CMD_CHIP_mA_AC) {
	               unit_str = "mA";
	           }
	           else if (last_rotary_cmd == CMD_CHIP_10A_DC || last_rotary_cmd == CMD_CHIP_10A_AC) {
	               unit_str = "A ";
	           }

	           // 1. REŽIM PRE 2-STUPŇOVÉ ROZSAHY S HODNOTOU 60 (mV, uA, mA)
	           if (current_pos == SWITCH_POS_mV || current_pos == SWITCH_POS_uA || current_pos == SWITCH_POS_mA) {
	               switch (MeasChip.range) {
	                   case 0:
	                       if (current_pos == SWITCH_POS_mV || current_pos == SWITCH_POS_mA) {
	                           // Rozsah 60.00 mV / 60.00 mA (Bodka za druhou cifrou)
	                           LCD_Draw7SegDot(10 + (3 * digit_step) - 9, 70, txt_color, LCD_BLACK);
	                           char text_buf_2scale0[20];
	                           snprintf(text_buf_2scale0, sizeof(text_buf_2scale0), "%s 60.00 %s", range_mode_str, unit_str);
	                           LCD_DrawString(20, 45, text_buf_2scale0, LCD_WHITE, LCD_BLACK, 2);
	                       } else {
	                           // Rozsah 600.0 uA (Bodka za treťou cifrou)
	                           LCD_Draw7SegDot(10 + (4 * digit_step) - 9, 70, txt_color, LCD_BLACK);
	                           char text_buf_ua0[20];
	                           snprintf(text_buf_ua0, sizeof(text_buf_ua0), "%s 600.0 %s", range_mode_str, unit_str);
	                           LCD_DrawString(20, 45, text_buf_ua0, LCD_WHITE, LCD_BLACK, 2);
	                       }
	                       break;

	                   case 1:
	                       if (current_pos == SWITCH_POS_mV || current_pos == SWITCH_POS_mA) {
	                           // Rozsah 600.0 mV / 600.0 mA (Bodka za treťou cifrou)
	                           LCD_Draw7SegDot(10 + (4 * digit_step) - 9, 70, txt_color, LCD_BLACK);
	                           char text_buf_2scale1[20];
	                           snprintf(text_buf_2scale1, sizeof(text_buf_2scale1), "%s 600.0 %s", range_mode_str, unit_str);
	                           LCD_DrawString(20, 45, text_buf_2scale1, LCD_WHITE, LCD_BLACK, 2);
	                       } else {
	                           // Rozsah 6000 uA (Čisté číslo bez bodky, tvoja úprava s medzerou)
	                           char text_buf_ua1[20];
	                           snprintf(text_buf_ua1, sizeof(text_buf_ua1), "%s 6000 %s ", range_mode_str, unit_str);
	                           LCD_DrawString(20, 45, text_buf_ua1, LCD_WHITE, LCD_BLACK, 2);
	                       }
	                       break;
	               }
	           }
	           // 2. OPRAVENÝ REŽIM PRE 10A: Čip posiela rozsah 0x00 pre 6.000 A a 0x01 pre 10.00 A
	           else if (current_pos == SWITCH_POS_10A) {
	               switch (MeasChip.range) {
	                   case 0: // Čip posiela 0x00 -> Rozsah 6.000 A (Bodka za prvou cifrou)
	                       LCD_Draw7SegDot(10 + (2 * digit_step) - 9, 70, txt_color, LCD_BLACK);

	                       char text_buf_10a_0[24];
	                       snprintf(text_buf_10a_0, sizeof(text_buf_10a_0), "%s 6.000 %s", range_mode_str, unit_str);
	                       LCD_DrawString(20, 45, text_buf_10a_0, LCD_WHITE, LCD_BLACK, 2);
	                       break;

	                   case 1: // Čip posiela 0x01 -> Rozsah 10.00 A (Bodka za druhou cifrou)
	                       LCD_Draw7SegDot(10 + (3 * digit_step) - 9, 70, txt_color, LCD_BLACK);

	                       char text_buf_10a_1[24];
	                       snprintf(text_buf_10a_1, sizeof(text_buf_10a_1), "%s 10.00 %s", range_mode_str, unit_str);
	                       LCD_DrawString(20, 45, text_buf_10a_1, LCD_WHITE, LCD_BLACK, 2);
	                       break;

	                   default:
	                       break;
	               }
	           }

	           // 3. ŠTANDARDNÉ ROZSAHY VELKÉHO NAPÄTIA (VÝHRADNE PRE POLOHU SWITCH_POS_V)
	           else {
	               switch (MeasChip.range) {
	                   case 0:
	                       LCD_Draw7SegDot(10 + (4 * digit_step) - 9, 70, txt_color, LCD_BLACK);
	                       char text_buf0[20];
	                       snprintf(text_buf0, sizeof(text_buf0), "%s 600.0 %s", range_mode_str, unit_str);
	                       LCD_DrawString(20, 45, text_buf0, LCD_WHITE, LCD_BLACK, 2);
	                       break;

	                   case 1:
	                       LCD_Draw7SegDot(10 + (2 * digit_step) - 9, 70, txt_color, LCD_BLACK);
	                       char text_buf1[20];
	                       snprintf(text_buf1, sizeof(text_buf1), "%s 6.000 %s", range_mode_str, unit_str);
	                       LCD_DrawString(20, 45, text_buf1, LCD_WHITE, LCD_BLACK, 2);
	                       break;

	                   case 2:
	                       LCD_Draw7SegDot(10 + (3 * digit_step) - 9, 70, txt_color, LCD_BLACK);
	                       char text_buf2[20];
	                       snprintf(text_buf2, sizeof(text_buf2), "%s 60.00 %s", range_mode_str, unit_str);
	                       LCD_DrawString(20, 45, text_buf2, LCD_WHITE, LCD_BLACK, 2);
	                       break;

	                   case 3:
	                       LCD_Draw7SegDot(10 + (4 * digit_step) - 9, 70, txt_color, LCD_BLACK);
	                       char text_buf3[20];
	                       snprintf(text_buf3, sizeof(text_buf3), "%s 600.0 %s", range_mode_str, unit_str);
	                       LCD_DrawString(20, 45, text_buf3, LCD_WHITE, LCD_BLACK, 2);
	                       break;

	                   case 4:
	                       char text_buf4[20];
	                       snprintf(text_buf4, sizeof(text_buf4), "%s 1000 %s ", range_mode_str, unit_str);
	                       LCD_DrawString(20, 45, text_buf4, LCD_WHITE, LCD_BLACK, 2);
	                       break;
	               }
	           }

	           MeasChip.is_valid = false;
	       }





	       end_of_display_loop:
	       HAL_Delay(5);



	   } // <--- TÁTO ZÁTVORKA PERFEKTNE UZATVÁRA CYKLUS while(1)
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV16;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART6) {
        // 1. Pošleme bajt do stavového parsera
        MeasChip_ProcessByte(rx_byte);

        // 2. Zárove�? ho zapíšeme do debug zberu pre displej
        if (debug_rx_index < 16) {
            debug_rx_buffer[debug_rx_index++] = rx_byte;
        } else {
            // Rolling buffer (posun dát), aby sme videli najnovšie prichádzajúce bajty
            for(int i = 0; i < 15; i++) {
                debug_rx_buffer[i] = debug_rx_buffer[i+1];
            }
            debug_rx_buffer[15] = rx_byte;
        }

        // Znova aktivujeme príjem
        HAL_UART_Receive_IT(&huart6, &rx_byte, 1);
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
