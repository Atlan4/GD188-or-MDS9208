/*
 * button.c
 *
 *  Created on: Nov 10, 2026
 *      Author: 42190
 */


// button.c
#include "button.h"
#include "lcd.h" // Potrebné pre výpis na displej
#include <stdio.h>
//#include "meas_control.h" // Potrebné pre prístup k SwitchPosition_t a SubMode_t


extern volatile uint8_t exti_button_cmd;

// Inicializácia tlačidiel
void BUTTON_Init(void) {
    // V KĽUDE DRŽÍME OBA VÝSTUPY NA LOGICKEJ 0!
    // Vďaka tomu stlačenie AKÉHOKOĽVEK tlačidla okamžite vyvolá EXTI prerušenie.
    HAL_GPIO_WritePin(OUT_K246_GPIO_Port, OUT_K246_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(OUT_K357_GPIO_Port, OUT_K357_Pin, GPIO_PIN_RESET);
}

// Globálna premenná, ktorú bude main.c bleskovo čítať
//volatile uint8_t exti_button_cmd = 0x00;

// button.c

// button.c

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
    // 1. Čistý softvérový filter na báze ticks bez blokovania SysTicku
    static uint32_t last_exti_tick = 0;
    uint32_t current_tick = HAL_GetTick();

    // Zvýšený filter pre potlačenie počiatočných iskrení gumičky na 250ms
    if (current_tick - last_exti_tick < 250) {
        // Okamžite čistíme Pending príznak hardvéru, aby sa nevytváral rad falošných prerušení
        EXTI->PR = GPIO_Pin;
        return;
    }
    last_exti_tick = current_tick;

    ButtonType_t detected_btn = BTN_NONE;

    // --- SAMOTNÝ BLESKOVÝ HARDVÉROVÝ SKEN MATICE ---
    if (GPIO_Pin == IN_K1_Pin) {
        detected_btn = BTN_BL;
    }
    else {
        HAL_GPIO_WritePin(OUT_K246_GPIO_Port, OUT_K246_Pin, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(OUT_K357_GPIO_Port, OUT_K357_Pin, GPIO_PIN_SET);
        for(volatile int i=0; i<50; i++); // Krátka pauza v inštrukciách procesora (bezpečné nanosekundy)

        if (HAL_GPIO_ReadPin(IN_K2_K3_GPIO_Port, IN_K2_K3_Pin) == GPIO_PIN_RESET) detected_btn = BTN_F1;
        if (HAL_GPIO_ReadPin(IN_K4_K5_GPIO_Port, IN_K4_K5_Pin) == GPIO_PIN_RESET) detected_btn = BTN_F3;
        if (HAL_GPIO_ReadPin(IN_K6_K7_GPIO_Port, IN_K6_K7_Pin) == GPIO_PIN_RESET) detected_btn = BTN_AUTO;

        if (detected_btn == BTN_NONE) {
            HAL_GPIO_WritePin(OUT_K246_GPIO_Port, OUT_K246_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(OUT_K357_GPIO_Port, OUT_K357_Pin, GPIO_PIN_RESET);
            for(volatile int i=0; i<50; i++);

            if (HAL_GPIO_ReadPin(IN_K2_K3_GPIO_Port, IN_K2_K3_Pin) == GPIO_PIN_RESET) detected_btn = BTN_F2;
            if (HAL_GPIO_ReadPin(IN_K4_K5_GPIO_Port, IN_K4_K5_Pin) == GPIO_PIN_RESET) detected_btn = BTN_F4;
            if (HAL_GPIO_ReadPin(IN_K6_K7_GPIO_Port, IN_K6_K7_Pin) == GPIO_PIN_RESET) detected_btn = BTN_SAVE;
        }
    }

    // --- SPRACOVANIE AKCIE ---
    if (detected_btn != BTN_NONE) {
        SwitchPosition_t current_pos = ROTARY_GetSwitchPosition();
        extern SubMode_t current_sub_mode;
        extern volatile uint8_t exti_button_cmd;


        extern volatile bool is_hold_active; // Sprístupníme globálny flag zamrazenia

        switch (detected_btn) {
            case BTN_F1: // REL (Tlačidlo F1)
                is_hold_active = false; // ZMENA: Stlačenie REL okamžite ruší zamrazenie dát!
                // Sem neskôr doplníme reálny kód pre REL funkciu čipu
                break;

        case BTN_F2: // Tlačidlo F2 (HOLD) stlačené priamo v EXTI prerušení
            {
            	 is_hold_active = !is_hold_active; // Prepína stav HOLD (Zopne / Vypne)
            }
            break;

            case BTN_F3: // SEL (Tlačidlo F3)
            	is_hold_active = false; // ZMENA: Prepnutie AC/DC sub-módu okamžite ruší HOLD!

                current_sub_mode = ROTARY_GetNextSubMode(current_pos, current_sub_mode);
                exti_button_cmd = ROTARY_GetChipCommand(current_pos, current_sub_mode);
                break;

            case BTN_F4: // RNG (Manuálny rozsah)
                if (current_pos == SWITCH_POS_V || current_pos == SWITCH_POS_mV ||
                    current_pos == SWITCH_POS_uA || current_pos == SWITCH_POS_mA ||
                    current_pos == SWITCH_POS_10A) {
                	is_hold_active = false; // ZMENA: Návrat do automatiky okamžite
                    exti_button_cmd = CMD_CHIP_MANUAL;
                }
                break;

            case BTN_AUTO: // Návrat do AUTO
            	is_hold_active = false; // ZMENA: Návrat do automatiky okamžite
                exti_button_cmd = CMD_CHIP_AUTO;
                break;

            case BTN_BL: // Trojstupňový jas podsvietenia (50% -> 75% -> 25% -> 50%...)
                {
                    static uint8_t level = 50;
                    if (level == 50)       level = 75;
                    else if (level == 75)  level = 25;
                    else                   level = 50;

                    TIM5->CCR4 = level;
                }
                break;

            default:
                break;
        }
        // Ak stlačenie akéhokoľvek tlačidla zmenilo/zrušilo stav HOLD,
        // vynútime jednorazové prekreslenie spodného menu pre okamžitú aktualizáciu farby políčka
        LCD_DrawBottomMenu(current_pos);
    }

    // --- RE-INICIALIZÁCIA PRE ĎALŠIE BUDENIE ---
    // Vraciame budiace linky matice trvalo na logickú 0
    HAL_GPIO_WritePin(OUT_K246_GPIO_Port, OUT_K246_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(OUT_K357_GPIO_Port, OUT_K357_Pin, GPIO_PIN_RESET);

    // [OPRAVA]: ZMAZANÝ NEBEZPEČNÝ HAL_DELAY
    // Okamžite čistíme hardvérový register čakajúcich prerušení (Pending register)
    EXTI->PR = GPIO_Pin;
}
