/*
 * lcd.c
 *
 *  Created on: Nov 4, 2026
 *      Author: 42190
 */


#include "lcd.h"
#include "font5x7.h"
#include "font7seg.h"
//#include "rotary_switch.h"
#include "button.h"
//#include "meas_chip.h"

// Zviditeľnenie štruktúry časovača TIM5, ktorá je definovaná v main.c
extern TIM_HandleTypeDef htim5;



// Safe and verified write to PB0-PB7 via BSRR register (Will not affect PB11, PB13, PB14, PB15)
__STATIC_INLINE void LCD_WriteBus(uint8_t byte) {
    GPIOB->BSRR = 0x00FF0000 | (uint32_t)byte;
}

// Hardware power initialization
void LCD_Power_Accessories(void) {
    // Turn on power to electronics (PA2 = 1)
    LCD_PWR_PORT->BSRR = (1 << LCD_PWR_PIN);
}


// Hardware pins and signal lines initialization
void LCD_Init_Hardware(void) {
    // Statically unlock RD pin (PB13 = 1)
    LCD_RD_PORT->BSRR = (1 << LCD_RD_PIN);

    // Hardware reset sequence via unlocked PC8 pin
    LCD_RST_PORT->BSRR = (1 << (LCD_RST_PIN + 16)); // RST = 0 (0V - reset active)
    HAL_Delay(20);
    LCD_RST_PORT->BSRR = (1 << LCD_RST_PIN);        // RST = 1 (3.3V - reset released)
    HAL_Delay(10);

    // Set default idle state for WR and RS lines (Logical 1)
    GPIOB->BSRR = (1 << LCD_WR_PIN);
    GPIOB->BSRR = (1 << LCD_RS_PIN);
}

void LCD_Init(void) {
// Initialize hardware display engine config registers
  LCD_WriteCommand(0x01); // Software Reset
  HAL_Delay(150);//20
  LCD_WriteCommand(0x11); // Sleep Out
  HAL_Delay(10);

  // Memory Data Access Control (Display orientation configuration)
  LCD_WriteCommand(0x36);
  LCD_WriteData(0x60);    // Landscape orientation orientation layout
  LCD_WriteCommand(0x3A); // Pixel Format
  LCD_WriteData(0x55);    // RGB565
  LCD_WriteCommand(0x29); // Display ON

  // Clean the screen canvas
  LCD_Clear(LCD_BLACK);
  HAL_Delay(80);

  // Turn on backlight LEDs
  //LCD_BL_on();
  LCD_BL_SetBrightness(25); // Maximálny výkon podsvietenia
  LCD_BL_on();

  }

// Turn on display backlight
void LCD_BL_on(void) {
    // Turn on backlight pin (PB11 = 1)
    //LCD_BL_PORT->BSRR = (1 << LCD_BL_PIN);
    /* USER CODE BEGIN 2 */
// Spustí hardvérové generovanie PWM na kanáli 4 pre TIM5
	HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_4);
/* USER CODE END 2 */

}



// 2. Nová funkcia na zápis jasu 0-100% pre TIM5 cez HAL makro
void LCD_BL_SetBrightness(uint8_t duty) {
    if (duty > 100) duty = 100;

    // Zápis striedy priamo do registra CCR4 pre časovač TIM5
    __HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_4, duty);
}


// Write configuration command (RS = 0)
void LCD_WriteCommand(uint8_t cmd) {
    GPIOB->BSRR = (1 << (LCD_RS_PIN + 16));  // RS = 0 (Command mode)

    LCD_WriteBus(cmd);

    GPIOB->BSRR = (1 << (LCD_WR_PIN + 16));  // WR = 0 (Clock pulse low)
    __NOP();                                 // Stabilization delay
    GPIOB->BSRR = (1 << LCD_WR_PIN);         // WR = 1 (Latch command byte)
    __NOP();
}

// Write data byte or pixel color data (RS = 1)
void LCD_WriteData(uint8_t data) {
    GPIOB->BSRR = (1 << LCD_RS_PIN);         // RS = 1 (Data mode)

    LCD_WriteBus(data);

    GPIOB->BSRR = (1 << (LCD_WR_PIN + 16));  // WR = 0 (Clock pulse low)
    __NOP();
    GPIOB->BSRR = (1 << LCD_WR_PIN);         // WR = 1 (Latch data byte)
    __NOP();
}

// Clear entire screen to a single color
void LCD_Clear(uint16_t color) {
    LCD_SetAddressWindow(0, 0, LCD_WIDTH - 1, LCD_HEIGHT - 1);
    uint8_t hi = color >> 8, lo = color & 0xFF;
    for (uint32_t i = 0; i < (LCD_WIDTH * LCD_HEIGHT); i++) {
        LCD_WriteData(hi);
        LCD_WriteData(lo);
    }
}

//**************************************************************************

// Set drawing window coordinates on the display
void LCD_SetAddressWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
    LCD_WriteCommand(0x2A); // Column Address Set
    LCD_WriteData(x0 >> 8); LCD_WriteData(x0 & 0xFF);
    LCD_WriteData(x1 >> 8); LCD_WriteData(x1 & 0xFF);

    LCD_WriteCommand(0x2B); // Row Address Set
    LCD_WriteData(y0 >> 8); LCD_WriteData(y0 & 0xFF);
    LCD_WriteData(y1 >> 8); LCD_WriteData(y1 & 0xFF);

    LCD_WriteCommand(0x2C); // Memory Write
}

// Draw a single character using font bitmap
void LCD_DrawChar(uint16_t x, uint16_t y, char c, uint16_t color, uint16_t bg, uint8_t size) {
    if (c < 32 || c > 127) c = ' ';
    uint16_t font_index = (c - 32) * 5;

    for (uint8_t i = 0; i < 5; i++) {
        uint8_t line = font5x7[font_index + i];
        for (uint8_t j = 0; j < 8; j++) {
            if (line & 0x01) {
                if (size == 1) LCD_DrawPixel(x + i, y + j, color);
                else {
                    for (uint8_t sx = 0; sx < size; sx++) {
                        for (uint8_t sy = 0; sy < size; sy++) {
                            LCD_DrawPixel(x + (i * size) + sx, y + (j * size) + sy, color);
                        }
                    }
                }
            } else if (bg != color) {
                if (size == 1) LCD_DrawPixel(x + i, y + j, bg);
                else {
                    for (uint8_t sx = 0; sx < size; sx++) {
                        for (uint8_t sy = 0; sy < size; sy++) {
                            LCD_DrawPixel(x + (i * size) + sx, y + (j * size) + sy, bg);
                        }
                    }
                }
            }
            line >>= 1;
        }
    }
}

// Draw a single pixel within display boundary limits
void LCD_DrawPixel(uint16_t x, uint16_t y, uint16_t color) {
    if (x >= LCD_WIDTH || y >= LCD_HEIGHT) return;
    LCD_SetAddressWindow(x, y, x, y);
    LCD_WriteData(color >> 8);
    LCD_WriteData(color & 0xFF);
}

// Fast horizontal line drawing for landscape mode
void LCD_DrawFastHLine(uint16_t x, uint16_t y, uint16_t w, uint16_t color) {
    if (y >= LCD_HEIGHT || x >= LCD_WIDTH) return;
    if ((x + w) > LCD_WIDTH) w = LCD_WIDTH - x;
    LCD_SetAddressWindow(x, y, x + w - 1, y);
    uint8_t hi = color >> 8, lo = color & 0xFF;
    for (uint16_t i = 0; i < w; i++) {
        LCD_WriteData(hi);
        LCD_WriteData(lo);
    }
}

// Fast vertical line drawing for landscape mode
void LCD_DrawFastVLine(uint16_t x, uint16_t y, uint16_t h, uint16_t color) {
    if (x >= LCD_WIDTH || y >= LCD_HEIGHT) return;
    if ((y + h) > LCD_HEIGHT) h = LCD_HEIGHT - y;
    LCD_SetAddressWindow(x, y, x, y + h - 1);
    uint8_t hi = color >> 8, lo = color & 0xFF;
    for (uint16_t i = 0; i < h; i++) {
        LCD_WriteData(hi);
        LCD_WriteData(lo);
    }
}

// Draw oscilloscope background grid (Scales up to 320x240 screen area)
void LCD_DrawGrid(uint16_t step, uint16_t color) {
    for (uint16_t y = step; y < LCD_HEIGHT; y += step) {
        LCD_DrawFastHLine(0, y, LCD_WIDTH, color);
    }
    for (uint16_t x = step; x < LCD_WIDTH; x += step) {
        LCD_DrawFastVLine(x, 0, LCD_HEIGHT, color);
    }
}

// Draw text string with automatic 320px border word-wrap tracking
void LCD_DrawString(uint16_t x, uint16_t y, const char* str, uint16_t color, uint16_t bg, uint8_t size) {
    while (*str) {
        LCD_DrawChar(x, y, *str++, color, bg, size);
        x += 6 * size;
        if (x + 6 * size >= LCD_WIDTH) {
            x = 0;
            y += 8 * size;
        }
    }
}

//*************************************************************************************

// Vykreslí na spodku obrazovky 4 samostatné políčka s popiskami funkcií tlačidiel
void LCD_DrawBottomMenu(SwitchPosition_t pos) {
    uint16_t menu_y = 210;
    uint16_t menu_h = 30;
    extern volatile bool is_hold_active; // Sprístupníme stav z main.c

    // 1. Vykreslenie vonkajšieho obdĺžnika
    LCD_DrawFastHLine(0, menu_y, 320, LCD_WHITE);
    LCD_DrawFastHLine(0, menu_y + menu_h - 1, 320, LCD_WHITE);
    LCD_DrawFastVLine(0, menu_y, menu_h, LCD_WHITE);
    LCD_DrawFastVLine(319, menu_y, menu_h, LCD_WHITE);

    // 2. Vykreslenie 3 vnútorných zvislých deliacich čiar
    LCD_DrawFastVLine(80,  menu_y, menu_h, LCD_WHITE);
    LCD_DrawFastVLine(160, menu_y, menu_h, LCD_WHITE);
    LCD_DrawFastVLine(240, menu_y, menu_h, LCD_WHITE);

    // 3. Vyčistenie vnútra políčok
    for(int r = 1; r < (menu_h - 1); r++) {
        LCD_DrawFastHLine(1,   menu_y + r, 78,  LCD_BLACK); // F1

        // ZMENA: Ak je HOLD aktívny, 2. políčko vyfarbíme na ORANŽOVO, inak na ČIERNO
        if (is_hold_active) {
            LCD_DrawFastHLine(81,  menu_y + r, 78,  LCD_ORANGE);
        } else {
            LCD_DrawFastHLine(81,  menu_y + r, 78,  LCD_BLACK);
        }

        LCD_DrawFastHLine(161, menu_y + r, 78,  LCD_BLACK); // F3
        LCD_DrawFastHLine(241, menu_y + r, 78,  LCD_BLACK); // F4
    }

    // 4. Dynamické priradenie textov a farieb podľa stavu HOLD
    uint16_t hold_text_color = (is_hold_active) ? LCD_BLACK : LCD_ORANGE;
    uint16_t hold_bg_color   = (is_hold_active) ? LCD_ORANGE : LCD_BLACK;

    if (pos == SWITCH_POS_V || pos == SWITCH_POS_mV ||
        pos == SWITCH_POS_uA || pos == SWITCH_POS_mA || pos == SWITCH_POS_10A)
    {
        LCD_DrawString(25,  menu_y + 7, "REL",  LCD_CYAN,   LCD_BLACK, 2);
        // Tvoja upravená pozícia X=100 s dynamickou farbou textu a pozadia
        LCD_DrawString(100, menu_y + 7, "HOLD", hold_text_color, hold_bg_color, 2);
        LCD_DrawString(185, menu_y + 7, "SEL",  LCD_WHITE,  LCD_BLACK, 2);
        LCD_DrawString(265, menu_y + 7, "RNG",  LCD_YELLOW, LCD_BLACK, 2);
    }
    else if (pos == SWITCH_POS_OHM_DIODE_CONT) {
        LCD_DrawString(25,  menu_y + 7, "---",  LCD_GREY,   LCD_BLACK, 2);
        LCD_DrawString(100, menu_y + 7, "HOLD", hold_text_color, hold_bg_color, 2);
        LCD_DrawString(185, menu_y + 7, "SEL",  LCD_WHITE,  LCD_BLACK, 2);
        LCD_DrawString(265, menu_y + 7, "---",  LCD_GREY,   LCD_BLACK, 2);
    }
    else if (pos == SWITCH_POS_Hz_Pct) {
        LCD_DrawString(25,  menu_y + 7, "---",  LCD_GREY,   LCD_BLACK, 2);
        LCD_DrawString(100, menu_y + 7, "HOLD", hold_text_color, hold_bg_color, 2);
        LCD_DrawString(185, menu_y + 7, "SEL",  LCD_WHITE,  LCD_BLACK, 2);
        LCD_DrawString(265, menu_y + 7, "---",  LCD_GREY,   LCD_BLACK, 2);
    }
    else {
        LCD_DrawString(25,  menu_y + 7, "---",  LCD_GREY,   LCD_BLACK, 2);
        LCD_DrawString(100, menu_y + 7, "HOLD", hold_text_color, hold_bg_color, 2);
        LCD_DrawString(185, menu_y + 7, "---",  LCD_GREY,   LCD_BLACK, 2);
        LCD_DrawString(265, menu_y + 7, "---",  LCD_GREY,   LCD_BLACK, 2);
    }
}



//*************************************************************************************

// Vykreslenie znaku 45x72 v pomere 1:1
void LCD_Draw7SegDigit(uint16_t x, uint16_t y, char num, uint16_t color, uint16_t bg) {
    uint8_t font_idx = 11;
    if (num >= '0' && num <= '9') font_idx = num - '0';
    else if (num == '-') font_idx = 10;
    else if (num == ' ') font_idx = 11;

    for (uint8_t j = 0; j < FONT_7SEG_HEIGHT; j++) {
        for (uint8_t byte_idx = 0; byte_idx < FONT_7SEG_BYTES_PER_ROW; byte_idx++) {
            uint8_t byte_val = font_7seg[font_idx][j * FONT_7SEG_BYTES_PER_ROW + byte_idx];

            for (uint8_t bit = 0; bit < 8; bit++) {
                uint8_t x_pixel = byte_idx * 8 + bit;
                if (byte_val & (0x80 >> bit)) {
                    LCD_DrawPixel(x + x_pixel, y + j, color);
                } else if (bg != color) {
                    LCD_DrawPixel(x + x_pixel, y + j, bg);
                }
            }
        }
    }
}

// Desatinná bodka prispôsobená pre 72px výšku (rozmer 7x7 pixelov)
void LCD_Draw7SegDot(uint16_t x, uint16_t y, uint16_t color, uint16_t bg) {
    uint16_t dot_w = 7;
    uint16_t dot_h = 7;
    uint16_t dot_y = y + (FONT_7SEG_HEIGHT - dot_h); // Automaticky lícuje so spodkom 72px

    LCD_SetAddressWindow(x, dot_y, x + dot_w - 1, dot_y + dot_h - 1);
    uint8_t hi = color >> 8, lo = color & 0xFF;
    for (uint16_t i = 0; i < (dot_w * dot_h); i++) {
        LCD_WriteData(hi);
        LCD_WriteData(lo);
    }
}

