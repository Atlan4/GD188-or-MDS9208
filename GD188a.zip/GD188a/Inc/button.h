/*
 * button.h
 *
 *  Created on: Nov 10, 2026
 *      Author: 42190
 */

// button.h
// Matrix and standalone button handling using CubeMX User Labels

// button.h
#ifndef BUTTON_H_
#define BUTTON_H_

#include <stdint.h>
#include "main.h"
#include "gpio.h"
#include "meas_chip.h" // Potrebné pre prístup k SwitchPosition_t a SubMode_t
#include "rotary_switch.h"

typedef enum {
    BTN_NONE = 0,
    BTN_F1,
    BTN_F2,
    BTN_F3,
    BTN_F4,
    BTN_AUTO,
    BTN_BL,
    BTN_SAVE
} ButtonType_t;

// Exportované funkcie
void BUTTON_Init(void);
ButtonType_t BUTTON_Scan(void);

// NOVÁ FUNKCIA: Túto zavoláš v hlavnej slučke main.c
uint8_t BUTTON_ProcessActions(SwitchPosition_t current_pos, SubMode_t *p_sub_mode);

#endif // BUTTON_H_




