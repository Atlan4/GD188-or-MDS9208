/*
 * dtm0660.h
 *
 *  Created on: Nov 4, 2026
 *      Author: 42190
 */

#ifndef MEAS_CHIP_H
#define MEAS_CHIP_H

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

extern UART_HandleTypeDef huart6;

typedef enum {
    MEAS_MODE_UNKNOWN,
    MEAS_MODE_DC_VOLTAGE
} MeasMode_t;

typedef enum {
    INIT_STEP_IDLE = 0,
    INIT_STEP_SET_MODE,   // Poslané 58 05 5D, čaká sa na echo
    INIT_STEP_SET_AUTO,   // Poslané 5A 5A, čaká sa na echo / odpoveď
    INIT_STEP_SET_MAN,    // PRIDANÝ STAV: Čakáme na potvrdenie manuálneho rozsahu (0x5B)
    INIT_STEP_READY       // Sekvencia hotová, môžeme periodicky posielať 60 60
} InitState_t;

typedef struct {
    MeasMode_t current_mode;
    InitState_t init_state;
    int16_t raw_value;
    uint8_t range;
    uint8_t packet_type;  // <-- TENTO RIADOK PRIDAJ
    bool is_valid;
    bool chip_present;
    uint32_t last_cmd_tick;
} MeasChip_t;




extern MeasChip_t MeasChip;

void MeasChip_Init(void);
void MeasChip_ProcessByte(uint8_t byte);
void MeasChip_RequestData(void);
void MeasChip_SetMode(MeasMode_t mode);
void MeasChip_SetRange(uint8_t mode_cmd);

#endif // MEAS_CHIP_H
